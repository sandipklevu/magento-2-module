<?php

use Magento\Framework\Component\ComponentRegistrar;

$registrar = new ComponentRegistrar();

if ($registrar->getPath(ComponentRegistrar::MODULE, 'Custom_Es') === null) {
    ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Custom_Es', __DIR__);
}
