<?php

namespace Custom\AttributeLoader\Cron;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Module\Manager;

class Run
{
    /**
     * @var Manager
     */
    private $moduleManager;

    public function __construct(Manager $moduleManager)
    {
        $this->moduleManager = $moduleManager;
    }

    public function execute()
    {
        $moduleManager = $this->moduleManager;

        if ($moduleManager->isEnabled('Custom_AttributeLoader')) {



        }
    }
}