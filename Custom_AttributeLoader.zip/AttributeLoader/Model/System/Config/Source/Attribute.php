<?php

namespace Custom\AttributeLoader\Model\System\Config\Source;

use Magento\Backend\Helper\Data;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Collection;
use Magento\Framework\Exception\LocalizedException;

/**
 *
 */
class Attribute extends Data
{

    /**
     * Array of same attributes for selected products
     *
     * @var Collection
     */
    protected $_attributes;

    /**
     * Excluded from batch update attribute codes
     *
     * @var string[]
     */
    protected $_excludedAttributes = ['url_key'];


    /**
     * @var Config
     */
    protected $_eavConfig;


    /**
     * @param Config $eavConfig
     */
    public function __construct(
        Config $eavConfig
    )
    {
        $this->_eavConfig = $eavConfig;
    }

    /**
     * Return collection of same attributes for selected products without unique
     *
     * @return array[]
     * @throws LocalizedException
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => null,
                'label' => '--- No Attribute Selected ---'
            ]
        ];
        if ($this->_attributes === null) {
            $this->_attributes = $this->_eavConfig->getEntityType(
                Product::ENTITY
            )->getAttributeCollection()
                ->setOrder('attribute_code','ASC');

            if ($this->_excludedAttributes) {
                $this->_attributes->addFieldToFilter('attribute_code', ['nin' => $this->_excludedAttributes]);
            }

            foreach ($this->_attributes as $attribute) {
                $options[] =
                    [
                        'value' => $attribute->getAttributeCode(),
                        'label' => $attribute->getAttributeCode()
                    ];
            }
        }

        return $options;
    }
}