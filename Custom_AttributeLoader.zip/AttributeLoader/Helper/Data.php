<?php

namespace Custom\AttributeLoader\Helper;


use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context as MageContext;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json as Mage_JSON;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface as StoreManager;

class Data extends AbstractHelper
{
    const XML_GENERAL_ATTRIBUTE_LOADER_STATUS = 'custom_attributeloader/general/enabled';
    const XML_GENERAL_ATTRIBUTE_LOADER_ATTRIBUTE = 'custom_attributeloader/general/attribute';
    const XML_GENERAL_ATTRIBUTE_LOADER_LOG = 'custom_attributeloader/general/log';

    protected $storeManager;
    protected $serialize;
    protected $request;

    /**
     * Data constructor
     *
     * @param MageContext $context
     * @param StoreManager $storeManager
     * @param Mage_JSON $serialize
     * @param CollectionFactory $productCollection
     */
    public function __construct(
        MageContext  $context,
        StoreManager $storeManager,
        Mage_JSON    $serialize

    )
    {
        $this->storeManager = $storeManager;
        $this->serialize = $serialize;
        parent::__construct($context);
        $this->request = $context->getRequest();

    }


    /**
     * @return int
     * @throws NoSuchEntityException
     */
    public function getStoreid()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function isEnabled()
    {
        return (bool)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_STATUS,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @return string
     * @throws NoSuchEntityException
     */
    public function getSelectedAttributeCode()
    {
        return $this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_ATTRIBUTE,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }

    /**
     * @return bool
     * @throws NoSuchEntityException
     */
    public function getLogEnabled()
    {
        return (bool)$this->scopeConfig->getValue(
            static::XML_GENERAL_ATTRIBUTE_LOADER_LOG,
            ScopeInterface::SCOPE_STORE,
            $this->getStoreid()
        );
    }
}