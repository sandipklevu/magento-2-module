<?php

namespace Custom\AttributeLoader\Console\Command;

use Custom\AttributeLoader\Helper\Data;
use Exception;
use Laminas\Log\Logger;
use Laminas\Log\Writer\Stream;
use Magento\Catalog\Api\ProductAttributeRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as Product_Model;
use Magento\Catalog\Model\ResourceModel\Attribute;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Console\Cli;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\App\Area;
use Magento\Framework\App\Filesystem\DirectoryList as DirectoryList;
use Magento\Framework\App\State;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\Store\Model\StoreManagerInterface as StoreManagerInterface;
use Psr\Log\LoggerInterface as LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Helper\ProgressBar;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as Magento_CollectionFactory;
use Magento\Catalog\Api\Data\ProductInterface;

class Run extends Command
{
    const AREA_CODE_LOCK_FILE = 'custom_attribute_areacode.lock';

    /**
     * @var ProductAttributeRepositoryInterface
     */
    protected $productAttributeRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var Attribute
     */
    protected $attributeResource;

    /**
     * @var State
     */
    protected $appState;

    /**
     * @var \Magento\Framework\EntityManager\EntityMetadata
     */
    protected $metadata;

    /**
     * @var State
     */
    protected $state;

    /**
     * @var StoreManagerInterface
     */
    protected $storeInterface;

    /**
     * @var DirectoryList
     */
    protected $directoryList;

    /**
     * @var LoggerInterface
     */
    protected $logger;
    private $productRepository;
    private $productCollection;
    private $productCollectionFactory;
    private $totalExecutionTime;
    private $startTime;
    private $filesystem;
    private $helper;
    private $perProductTotalExecutionTime;
    private $perProductStartTime;


    public function __construct(
        State                      $appState,
        StoreManagerInterface      $storeInterface,
        DirectoryList              $directoryList,
        LoggerInterface            $logger,
        Magento_CollectionFactory  $productCollectionFactory,
        ProductRepositoryInterface $productRepository,
        Filesystem                 $filesystem,
        Data                       $helper
    )
    {
        $this->appState = $appState;
        $this->storeInterface = $storeInterface;
        $this->directoryList = $directoryList;
        $this->logger = $logger;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productRepository = $productRepository;
        $this->filesystem = $filesystem;
        $this->helper = $helper;
        parent::__construct();
    }

    /**
     * Initialization of the command.
     */
    protected function configure()
    {
        $this->setName('custom:attributeloader');
        $this->setDescription('Executes some flows');
        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int
     * @throws LocalizedException
     * @throws FileSystemException
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->setDecorated(true);
        if (!$this->helper->isEnabled()) {
            $output->writeln(__(
                sprintf(' Module is disabled from backend')
            )->getText());
            return Cli::RETURN_SUCCESS;
        }
        $this->startTime = microtime(true);
        $logDir = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $storeLockFile = '';
        $areaCodeFile = $logDir . "/" . self::AREA_CODE_LOCK_FILE;
        try {
            if (file_exists($areaCodeFile)) {
                unlink($areaCodeFile);
            }
            $this->appState->setAreaCode(Area::AREA_FRONTEND);
        } catch (LocalizedException $e) {
            fopen($areaCodeFile, 'w');
            if ($this->appState->getAreaCode() != Area::AREA_FRONTEND) {
                $output->writeln(__(
                    sprintf('  Running in an unexpected state AreaCode : (%s)', $this->appState->getAreaCode())
                )->getText());
            }
        }

        try {
            $output->writeln("=== Starting process ===");
            $output->writeln('');

            $collection = $this->productCollectionFactory->create();
            $videoAttribute = $this->helper->getSelectedAttributeCode();
            $collection->addAttributeToSelect(array('id', 'sku', $videoAttribute));

            $progress = new ProgressBar($output, count($collection));
            $progress->setFormat('<comment>%message%</comment> %current%/%max% [%bar%] %percent:3s%% %elapsed%');
            $mediaPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
            $output->writeln($mediaPath);

            //$mediaPathFile = $mediaPath . '/video.mp4';

            foreach ($collection as $productKey => $product) {
                $this->perProductStartTime = microtime(true);
                if (!$product instanceof Product_Model) {
                    $this->log('Product not found valid.' . $productKey);
                    continue;
                }
                $proLabel = 'Key: ' . $productKey . '= SKU: ' . $product->getSku();
                $videoAttributeValue = $product->getDataUsingMethod($videoAttribute);
                if (!$videoAttributeValue || filter_var($videoAttributeValue, FILTER_VALIDATE_URL) === FALSE) {
                    $this->log('Product value "(' . $videoAttributeValue . ')" found empty or invalid for given product: ' . $proLabel);
                    continue;
                }
                //$mediaPathFile = $mediaPath . '/' . $productKey . '-' . $product->getDataUsingMethod('sku') . '.mp4';
                $mediaPathFile = $mediaPath . '/' . basename($videoAttributeValue) . PHP_EOL;
                if (file_exists($mediaPathFile)) {
                    $this->log('Product value ' . $proLabel . ' exists already on this path: ' . $mediaPathFile);
                    continue;
                }
                $output->writeln("Video started for product " . $proLabel);
                $videoVimeo = file_get_contents($videoAttributeValue);
                if (!$videoVimeo) {
                    $this->log('Video get contents not valid for product: ' . $proLabel);
                    continue;
                }
                $putStatus = file_put_contents($mediaPathFile, $videoVimeo);
                $this->perProductTotalExecutionTime = microtime(true) - $this->perProductStartTime;
                $diff = gmdate('H:i:s', intval($this->perProductTotalExecutionTime));
                if (false === $putStatus) {
                    $this->log('Video could not be put on path: ' . $proLabel);
                    continue;
                }
                $this->log('Time taken to put video for product ' . $proLabel . ' => ' . $diff);
                $progress->setMessage($product->getId() . ' ');
                $output->writeln("Completed " . $proLabel);
                $progress->advance();
                $output->writeln("");
            }
            $output->writeln('');
            $this->totalExecutionTime = microtime(true) - $this->startTime;
        } catch (Exception $e) {


            $output->writeln("");
            $output->writeln("<error>{$e->getMessage()}</error>");
            return Cli::RETURN_FAILURE;
        }
        $output->writeln('');
        $output->writeln('<info>Completed for all the products ' . gmdate('H:i:s', intval($this->totalExecutionTime)) . '</info>');
        return Cli::RETURN_SUCCESS;
    }

    /**
     * @param $message
     * @return void
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function log($message)
    {
        if (!$this->helper->getLogEnabled()) {
            return;
        }
        $writer = new Stream(BP . '/var/log/VideoCustomAttribute.log');
        $logger = new Logger();
        $logger->addWriter($writer);
        $logger->info($message);
    }
}